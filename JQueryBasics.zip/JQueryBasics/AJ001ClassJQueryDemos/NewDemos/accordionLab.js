function start(){
	$('#accordDiv').accordion({
		active : 1
	});


$('#acc3Select').click(function(){
	$('#accordDiv').accordion('option','active',2);
});

$('#acc4Add').click(function(){
	$('#accordDiv').append('<h1><a>Menu 4</a></h1>');
	$('#accordDiv').append('<div>Menu 4 Content</div>');
	$('#accordDiv').accordion('refresh');
	$('#accordDiv').accordion('option','active',3);
});

$('#acc1Remove').click(function(){
	$($('#accordDiv h1')[0]).remove();
	$($('#accordDiv div')[0]).remove();

});

$('#disAcc').click(function(){
	$('#accordDiv').accordion('option','disabled',true);
});

$('#enAcc').click(function(){
	$('#accordDiv').accordion('enable');
});

$('#loadAcc3').click(function(){
	$('#accordDiv div:last-child').load('/jq/jsp/getMessageText.jsp');
	$('#accordDiv').accordion('option','active',2);
});
$('#accordDiv').on('accordionactivate',function(event,ui){
	$(ui.newPanel).fadeToggle();
	$(ui.newPanel).fadeToggle(4000);
});
}
