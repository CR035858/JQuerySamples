function start(){
	var d=null;
	
	//DOM Insertion - Around
	$('#wrap1').click(function(){
		$('#l1').wrap('<p></p>');
	});
	
	$('#wrapAll').click(function(){
		$('#d1 label').wrapAll('</p>');
	});
	
	$('#wrapInner').click(function(){
		$('#l1').wrapInner('<strong></strong>');
	});
	
	//DOM Insertion - Inside
	$('#append').click(function(){
		$('#d3').append('<p>Appended Para</p>');
	});
	
	$('#prepend').click(function(){
		$('#d3').prepend('<p>Prepended Para</p>');
	});
	
	$('#appendTo').click(function(){
		$('<p>Appended Para</p>').appendTo('#d3');
	});
	
	$('#prependTo').click(function(){
		$('<p>Prepended Para</p>').prependTo('#d3');
	});
	
	//DOM Insertion - Outside
	$('#after').click(function(){
		$('#d3').after('<p>After Div 3</p>');
	});
	
	$('#before').click(function(){
		$('#d3').before('<p>Before Div 3</p>');
	});
	
	$('#insertAfter').click(function(){
		$('<p>After Div 3</p>').insertAfter('#d3');
	});
	
	$('#insertBefore').click(function(){
		$('<p>Before Div 3</p>').insertBefore('#d3');
	});
	
	//Remove elements
	$('#remEle2').click(function(){
		d = $('#d2').remove();
	});
	
	$('#empty').click(function(){
		$('#mainDiv').empty();
	});
	//events are retained with detach
	$('#detEle2').click(function(){
		d = $('#d2').detach();
	});
	
	$('#d2').click(function(){
		alert('Div2 clicked');
	});
	
	$('#attEle2').click(function(){
		if(d){
			d.appendTo($('#mainDiv'));
		}
	});
	
}