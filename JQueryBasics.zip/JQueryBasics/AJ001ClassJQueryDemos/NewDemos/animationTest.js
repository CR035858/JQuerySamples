function start(){
	
	$('#animFade').click(function(){
		$('#d1').animate({
			  'opacity': 0
		}, 1000);
	});
	
	$('#animWH').click(function(){
		$('#d1').animate({
			  'width': 700,
			  'height' : 400
		}, 2000,function() {
			  alert("Div is now 700x wide and 400px length!");
		});
	});
	
	$('#slideUp').click(function(){
		$('#d1').slideUp(2000);
	});
	
	$('#slideUpAnimate').click(function(){
		$('#d1').animate({
			'height'     : 0 ,
			'padding-top': 0
		},4000);
	});
	
	$('#slideDown').click(function(){
		$('#d1').slideDown(2000);
	});
	
	$('#slideToggle').click(function(){
		$('#d1').slideToggle(2000);
	});
	
}