function start(){
	
	$('#copyParaDataText').click(function(){
		var p1Data = $('#p1').text();
		$('#p2').text(p1Data);
	});
	
	$('#copyParaDataHtml').click(function(){
		var htmlContent = "<strong>"+$('#p1').text()+"</strong>";
		$('#p2').html(htmlContent);
	});
	
	$('#copyInputData').click(function(){
		var t1Data = $('#t1').val();
		$('#t2').val(t1Data);
	});
	
}