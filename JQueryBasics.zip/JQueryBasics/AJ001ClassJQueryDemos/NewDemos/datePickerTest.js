function start(){
	
	$('#dp1').datepicker();
	
	$('#dp2').datepicker({
		dateFormat : 'yy-MM-dd',
		changeYear : true
	});
	
	$('#dp3').datepicker({
		firstDay : 1
	});
	
	$('#dp4').datepicker({
		defaultDate: 3,
		minDate : -10,
		maxDate: 5
	});
	
	$('#dp5').datepicker({
		//rows columns
		numberOfMonths : [3, 2]
	});
}