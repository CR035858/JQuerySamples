function start(){
	
	$('#changeTitle').click(function(){
		$('#diaDiv').dialog({
			title : 'Non Draggable',
			draggable : false
		});
	});

	$('#doubleDia').click(function(){
		$('#diaDiv2, #diaDiv2_1').dialog();
	});
	
	$('#bDia').click(function(){
		$('#diaDiv3').dialog({
			dialogClass: "no-close",
			buttons : [
			           	{
			           		text : 'OK',
			           		click : function(){
			           			$(this).dialog('close');
			           		}
			           	}
			          ]
		});
	});
	
	$('#modalDia').click(function(){
		$('#diaDiv4').dialog({
			modal : true
		});
	});
	
	$('#posDia').click(function(){
		$('#diaDiv5').dialog({
			position : {
				of : '#mainDiv',
				at: 'center'
			}
		});
	});
	
	$('#noClsDia').click(function(){
		$('#diaDiv6').dialog({
			open: function(event,ui){
				$(".ui-dialog-titlebar-close").hide();
			}
		});
	});
}