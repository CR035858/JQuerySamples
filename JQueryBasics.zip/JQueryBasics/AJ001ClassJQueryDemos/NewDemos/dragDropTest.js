function start(){
	var i=0;
	$('#d1').draggable();
	
	$('#d2').draggable({
		containment : 'parent'
	});
	
	$('#d3').draggable({
		axis : 'x',
		containment : 'parent'
	});

	$('#d4').draggable({
		containment : 'parent',
		helper : 'clone',
		start : function (event, ui){
			console.log('Start Drag');
		},
		drag : function (event, ui){
			console.log('Dragging.....');
		},
		stop : function (event, ui){
			console.log('Stop Drag');
			var clonedDiv = ui.helper.clone();
			//for css
			clonedDiv[0].id = $(this)[0].id+'-'+(++i);
			//for text
			clonedDiv.appendTo($(this).parent());
		}
	});
	
	$('#d5').draggable({
		revert : true
	});
	
	$('#p6').droppable({
		accept : function(ui){
			if(ui[0].id=='d5'){
				return true;
			}
			return false;
		},
		drop : function (event, ui){
			console.log('Dropping.....');
			console.log(ui.helper);
			ui.draggable.appendTo($(this));
		}
	});
}