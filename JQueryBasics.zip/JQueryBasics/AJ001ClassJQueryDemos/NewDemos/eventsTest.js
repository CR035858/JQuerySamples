function start(){
	
	$('#d1').on('click',function(){
		alert('Box1 Clicked');
	});
	
	$('#d2').on('mouseover',function(){
		alert('Box2 Mouse over');
	});
	
	$('#d2').on('mouseout',function(){
		alert('Box2 Mouse out');
	});
	
	$('#d3').mouseover(function(){
		alert('Box3 Mouse over');
	});
	
	$('#d3').mouseout(function(){
		alert('Box3 Mouse out');
	});
	
	$('#d4').hover(
		function(){
			$(this).addClass('box3');
		},
		function(){
			$(this).removeClass('box3');
		}
	);
	
	$('#remD1Click').click(function(){
		$('#d1').off('click');
	});
	
	$('#remD2Mouse').click(function(){
		$('#d2').off('mouseover mouseout');
	});
	
	$('#remD3All').click(function(){
		$('#d3').off();
	});
	
	$('#t1').keyup(function(){
		$('#t2').val($(this).val());
	});
	
	$('#d6').click(function(){
		alert("Outer Box Clicked");
	});
	
	$('#innerDiv').click(function(event){
		event.stopImmediatePropagation();
		alert("Inner Box Clicked");
	});
	
	$('#buttonDiv').dblclick(function(event){
		alert('Box1 double click');
	});
	
	$('#a1').click(function(event){
		event.preventDefault();
	});
}