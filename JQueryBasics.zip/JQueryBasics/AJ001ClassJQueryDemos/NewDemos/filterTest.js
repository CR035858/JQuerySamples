function start(){
	
	$('#bChildren').click(function(){
		$('#d1').children('div').css('border','2px solid');
	});
	
	$('#bFind').click(function(){
		$('#d1').find('div').css('border','2px solid');
	});
	
	$('#bSiblings').click(function(){
		$('#d1>div:first-child').siblings().css('border','2px solid');
	});
	
	$('#bSiblingsAndSelf').click(function(){
		$('#d1>div:first-child').siblings().andSelf().css('border','2px solid');
	});
	
	$('#bFilter').click(function(){
		$('#d1').find('div').filter('div[id^="inner"]').css('border','2px solid');
	});
	
	$('#b5Clear').click(function(){
		$('#d1 div').css('border','0px');
	});
	
}