function start(){
	
	$('#b1').click(function(){
		$.ajax('/jq/jsp/userDetails.jsp',{
			type : 'POST',
			dataType : 'json',
			data : $('#f1').serialize(),
			success : function(result){
				var user = result.userDetails;
				loadUser(user);
			},
			error : function(xhr,status,error){
				$("#erroMsg").html("Please try later : "+error);
			}
		});
	});
}

function loadUser(user){
	$('#userName').append(user.userName);
	$('#userEmail').append(user.email);
	$('#userAddress').append(user.address);
	$('#userPhone').append(user.phone);
}