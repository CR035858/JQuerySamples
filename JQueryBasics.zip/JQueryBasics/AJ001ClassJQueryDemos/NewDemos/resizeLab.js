function start(){
	$('#p1').resizable({
		animate: true
	});
	
	$('#p2').resizable({
		minWidth : 100,
		minHeight : 100,
		maxWidth : 500,
		maxHeight : 500
	});
	//grid is steps
	$('#p3').resizable({
		minWidth : 100,
		minHeight : 100,
		maxWidth : 500,
		maxHeight : 500,
		grid: [ 100, 100 ]
	});
	//orange line is the helper
	$('#p4').resizable({
		minWidth : 100,
		minHeight : 100,
		maxWidth : 500,
		maxHeight : 500,
		handles: "n, e, s, w",
		helper: "rHelper"
	});
	//grey line which folows is the ghost
	$('#p5').resizable({
		minWidth : 100,
		minHeight : 100,
		maxWidth : 500,
		maxHeight : 500,
		ghost : true
	});
}