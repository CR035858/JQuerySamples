function start(){
	
	$('#b1').click(function(){
		$('#d1').css('background-color','red');
	});
	
	$('#b2').click(function(){
		$('#d2').css('background-color','green');
	});
	
	$('#b3').click(function(){
		$('#d3').css('background-color','yellow');
	});
	
	$('#b3Class').click(function(){
		$('.box3').css('background-color','#FFAFAF');
	});
	
	$('#bAll3Box').click(function(){
		$('div[id^="d"]').css('background-color','pink');
	});
	
	$('#bAllDivs').click(function(){
		$('div').css('background-color','#FF9900');
	});
	
	$('#bDivFirst').click(function(){
		$('div:first-child').css('background-color','#DD7745');
	});
	
	$('#bDiv2').click(function(){
		$('div:nth-child(2)').css('background-color','#FAAAA4');
	});
	
	$('#bDiv3').click(function(){
		$('div:nth-last-child(2)').css('background-color','#FFAAFF');
	});
	
	$('#bDivLast').click(function(){
		$('div:last-child').css('background-color','#FAFAD1');
	});
	
	$('#bDivMultiple').click(function(){
		$('#d1,#d2,div:last-child').css('background-color','#BABAFA');
	});
	
	$('#bDivByClass').click(function(){
		$('#d1').addClass('box3');
	});
	
	$('#clearAll').click(function(){
		$('div').css('background-color','inherit');
	});
	
}