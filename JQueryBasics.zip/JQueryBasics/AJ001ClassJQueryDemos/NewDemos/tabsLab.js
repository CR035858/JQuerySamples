function start(){
	$('#tabDiv').tabs({
		active : 1
	});
	
	$('#tab3Select').click(function(){
		$('#tabDiv').tabs('option','active',2);
	});
	
	$('#tab4Add').click(function(){
		$('#tabDiv ul').append('<li id="tab4Li"><a href="#tab4">Tab 4</a></li>');
		$('#tabDiv').append('<div id="tab4"> Tab 4 Content</div>');
		$('#tabDiv').tabs('refresh');
		$('#tabDiv').tabs('option','active',3);
	});
	
	$('#tab1Remove').click(function(){
		$('#tab1Li').remove();
		$('#tab1').remove();
	});
	
	$('#disTab2').click(function(){
		$('#tabDiv').tabs('disable',1);
	});
	
	$('#disTab').click(function(){
		$('#tabDiv').tabs('option','disabled',true);
	});
	
	$('#loadTab3').click(function(){
		$('#tab3').load('/jq/jsp/getMessageText.jsp');
		$('#tabDiv').tabs('option','active',2);
	});
	
	$('#tabDiv').on('tabsactivate',function(event,ui){
		$(ui.newPanel).fadeToggle();
		$(ui.newPanel).fadeToggle(4000);
	});
}