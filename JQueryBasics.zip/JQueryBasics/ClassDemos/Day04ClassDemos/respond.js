<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1" />
<meta content="IE=Edge" http-equiv="X-UA-Compatible" />
<meta name="msvalidate.01" content="8BAB7574F2CFB135874093D7FC22CA9A" />
<title>RESPOND.JS CDN links  - CDNPKG</title>
<meta name="description" content="1 CDN to use with RESPOND.JS. Find out the best CDN to use with respond.js or use multiple CDN as fallback. Simply copy and paste one of these URL !." />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.13/semantic.min.css">
<link rel="stylesheet" href="/css/main.css" />
<link rel="stylesheet" href="/css/site.css" />
<link rel="canonical" href="https://www.cdnpkg.com/respond.js" ">


<script async src="https://www.googletagmanager.com/gtag/js?id=UA-1016076-26"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments)};
  gtag('js', new Date());

  gtag('config', 'UA-1016076-26');
</script>
</head>
<body class="Site">
<div class="Site-header">
<div class="eyecatcher"></div>
<div class="ui stackable borderless main menu">
<div class="ui container">
<a href="/" class="header item">
<i class=""></i>&nbsp; CDNPKG .com
</a>
<form class="header item" action="/-/search">
<div class="ui icon large input">
<input type="text" name="q" value="" placeholder="Search file, library...">
<i class="search icon"></i>
</div>
<input type="hidden" name="t" value="lib">
</form>
<div class="right menu">
<div class="item"><a href="https://github.com/cdnpkg/cdnpkg.com" target="_blank"><i class="github icon"></i></a></div>
<div class="item"><a href="https://twitter.com/cdnpkg" target="_blank"><i class="twitter icon"></i></a></div>
</div>
</div>
</div>
<div class="eyecatcherbottom"></div> </div>
<div class="Site-content ui container">
<div class="ui small breadcrumb"><a class="section" href="/">Home</a>
<i class="right chevron icon divider"></i><div class="active section">respond.js</div></div> <script type="application/ld+json">{ "@context": "http://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [{
    "@type": "ListItem",
    "position": 0,
    "item": {
      "@id": "/",
      "name": "Home"
    }
  },
{
    "@type": "ListItem",
    "position": 1,
    "item": {
      "@id": "/respond.js",
      "name": "respond.js"
    }
  }]}</script>
<h1 class="ui dividing header"><small>RESPOND.JS CDNs</small></h1>
<table class="ui definition compact small table">
<tbody>
<tr>
<td>Description</td>
<td>min/max-width media query polyfill</td>
</tr>
<tr>
<td>Sources URL</td>
<td><a href="https://github.com/scottjehl/Respond" target="_blank" rel="nofollow noopener noreferrer">https://github.com/scottjehl/Respond</a></td>
</tr>
<tr>
<td>Version</td>
<td>1.4.2 <small><a href="/respond.js#versions">See all versions</a></small></td>
</tr>
<tr>
<td>Latest stable version</td>
<td><a href="/respond.js/1.4.2">1.4.2</a> (current) </td>
</tr>
<tr>
<td>Latest version</td>
<td>1.4.2 </td>
</tr>

<tr>
<td>Content Delivery Networks</td>
<td>
<span class="ui mini label">cdnjs</span>
</td>
</tr>
</tbody>
</table>
<h2 class="ui dividing header">
<small>CDN links </small>
</h2>
<table class="ui very basic compact small table" v-if="showFilesTable">
<thead>
<tr>
<th>File name</th>
<th>CDN</th>
<th>URL</th>
</tr>
</thead>
<tbody>
<tr>
<td>respond.js</td>
<td>cdnjs</td>
<td><a href="https://cdnjs.cloudflare.com/ajax/libs/respond.js/1.4.2/respond.js" target="_blank" rel="nofollow noopener noreferrer">https://cdnjs.cloudflare.com/ajax/libs/respond.js/1.4.2/respond.js</a></td>
</tr>
<tr>
<td>respond.min.js</td>
<td>cdnjs</td>
<td><a href="https://cdnjs.cloudflare.com/ajax/libs/respond.js/1.4.2/respond.min.js" target="_blank" rel="nofollow noopener noreferrer">https://cdnjs.cloudflare.com/ajax/libs/respond.js/1.4.2/respond.min.js</a></td>
</tr>
</tbody>
</table>





<h2 class="ui dividing header"><a name="versions"></a>
<small>Versions</small>
</h2>
<table class="ui celled compact small table">
<thead>
<tr>
<th>Version</th>
<th>CDN</th>
</tr>
</thead>
<tbody>
<tr>
<td><a href="/respond.js/1.4.2">1.4.2</a></td>
<td><span class="ui mini label">cdnjs</span></td>
</tr>
<tr>
<td><a href="/respond.js/1.4.1">1.4.1</a></td>
<td><span class="ui mini label">cdnjs</span></td>
</tr>
<tr>
<td><a href="/respond.js/1.4.0">1.4.0</a></td>
<td><span class="ui mini label">cdnjs</span></td>
</tr>
<tr>
<td><a href="/respond.js/1.3.0">1.3.0</a></td>
<td><span class="ui mini label">cdnjs</span></td>
</tr>
<tr>
<td><a href="/respond.js/1.2.0">1.2.0</a></td>
<td><span class="ui mini label">cdnjs</span></td>
</tr>
<tr>
<td><a href="/respond.js/1.1.0">1.1.0</a></td>
<td><span class="ui mini label">cdnjs</span></td>
</tr>
</tbody>
</table>
<h2 class="ui dividing header">
<small>All assets for respond.js</small>
</h2>
<table class="ui celled compact small table">
<thead>
<tr>
<th>File</th>
<th>CDN</th>
</tr>
</thead>
<tbody>
<tr>
<td><a href="/respond.js/file/respond.js/">respond.js</a></td>
<td><span class="ui mini label">cdnjs</span></td>
</tr>
<tr>
<td><a href="/respond.js/file/respond.min.js/">respond.min.js</a></td>
<td><span class="ui mini label">cdnjs</span></td>
</tr>
</tbody>
</table>
</div>
<div class="Site-footer">
<div class="ui inverted vertical footer segment" style="margin-top: 50px;">
<div class="ui container">
<div id="footer"><small>Copyright 2018 - cdnpkg.com</small>
</div>
</div>
</div>
</div>
<script async type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>

</body>
</html>